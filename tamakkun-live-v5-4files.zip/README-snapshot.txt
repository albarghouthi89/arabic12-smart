Snapshot of the deployed site (v5) — only the 4 files that differ from GitHub main.
Copy these 4 files over the same paths in a NEW branch (not main), e.g. snapshot/live-v5-2026-10-19.

index.html
js/app.js
js/questions-bank-data.js
js/questions-bank-ui.js

SHA-256 (first 16 hex) for verification:
74e9e58b6f87d62c  index.html
88791226de96fb52  js/app.js
4656b98c6c34c343  js/questions-bank-data.js
c8cab6ffb0aa7c73  js/questions-bank-ui.js
